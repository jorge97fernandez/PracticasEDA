//**********************************************************************************************************************
// Archivo: string_lib.cpp
// Autor:   Andrés Gavín Murillo 716358
// Autor:   Jorge Fernandez Muñoz 721529
// Fecha:   7 Noviembre 2018
// Coms:    EDA - Práctica 1 - Biblioteca para uso de strings.
//**********************************************************************************************************************

#include "string_lib.h"


string to_string(string s) {
    return s;
};
